﻿SELECT
*
FROM People